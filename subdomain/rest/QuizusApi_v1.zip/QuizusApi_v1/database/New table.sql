CREATE TABLE IF NOT EXISTS `users_api_auth` (
   `user_id` varchar(40) NOT NULL
  `api_key` varchar(32) NOT NULL,
  `status` int(1) NOT NULL DEFAULT '1',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  KEY (`user_id`),
  UNIQUE KEY `api_key` (`api_key`)
);



